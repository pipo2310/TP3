#ifndef GRUPO_H
#define GRUPO_H
#include "Miembro.h"
#include <list>


class Grupo
{
    public:
        Grupo();
        Grupo(Miembro);
        virtual ~Grupo();
        void agregarAGrupo(Miembro);

    protected:
    list<Miembro> grupo;
    Miembro m;
    private:
};

#endif // GRUPO_H
