#ifndef MIEMBRO_H
#define MIEMBRO_H
#include"Requerimentos.h"

class Miembro
{
    public:
        Miembro();
        virtual ~Miembro();
        void setData(string,Tarea);

    protected:
    string nombre;
    Tarea t;
    private:
};

#endif // MIEMBRO_H
