#include "Grupo.h"

Grupo::Grupo()
{
    //ctor
}

Grupo::~Grupo()
{
    //dtor
}
void Grupo::agregarAGrupo(Miembro miem)
{
     list<Miembro>::iterator iter;
     grupo.push_back(miem);
}
