#include "Miembro.h"

Miembro::Miembro()
{
   nombre="";
}

Miembro::~Miembro()
{
    //dtor
}
void Miembro::setData(string n,Tarea tar)
{
    nombre =n;
    t=tar;
}

