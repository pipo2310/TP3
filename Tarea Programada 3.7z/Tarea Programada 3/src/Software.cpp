#include "Software.h"

Software::Software()
{
    //ctor
}
Software::Software(string n)
{
    nombre=n;
}

Software::~Software()
{
    //dtor
}

void Software::agregueRequerimento(){
    string nom;
    string t;

    cout<<"Nombre del requerimento: "<<endl;
    cin>>nom;
    cout<<"Tipo: "<<endl;
    cin>>t;

    Requerimentos *r=new Requerimentos();
    r->setDatos(nom, t);
    r->setTareas();

    listaRequer.push_back(r);
}

string Software::muestreRequerimentos(){
    stringstream requerimentos;
    list<Requerimentos*>::iterator iter;
    for(iter=listaRequer.begin();iter!=listaRequer.end();iter++){
        requerimentos<<"Nombre: "<<(*iter)->getNombre()<<"\n"<<"Tipo: "<<(*iter)->getTipo()<<"\n"<<(*iter)->muestreTareas()<<endl;
    }
    return requerimentos.str();
}

void Software::modifiqueRequerimento(int instruccion){
    list<Requerimentos*>::iterator iter;
    string nv="";
    bool encontrado=false;
    switch(instruccion){
    case 1: //modifique nombre
    {
        string nn="";

        cout<<"Nombre del requerimento a modificar: "<<endl;
        cin>>nv;
        cout<<"Nuevo nombre del requerimento: "<<endl;
        cin>>nn;
        for(iter=listaRequer.begin();iter!=listaRequer.end();iter++){
            if((*iter)->getNombre()==nv){
                (*iter)->setNombre(nn);
                encontrado=true;
            }
        }
        if(!encontrado){
            cout<<"No existe un requerimento con ese nombre"<<endl;
        }
        break;
    }
    case 2: //modifique tipo
    {
        nv="";
        string tn="";

        cout<<"Nombre del requerimento a modificar: "<<endl;
        cin>>nv;
        cout<<"Nuevo tipo del requerimento: "<<endl;
        cin>>tn;
        for(iter=listaRequer.begin();iter!=listaRequer.end();iter++){
            if((*iter)->getNombre()==nv){
                (*iter)->setTipo(tn);
                encontrado=true;
            }
        }
            if(!encontrado){
            cout<<"No existe un requerimento con ese nombre"<<endl;
            }
            break;
    }
    case 3: //agregue tarea
        string nr;
        string n;
        int p;
        float esfEst;
        list<Requerimentos*>::iterator iter;

        cout<<"Nombre de la nueva tarea: "<<endl;
        cin>>n;
        cout<<"Prioridad: "<<endl;
        cin>>p;
        cout<<"Esfuerzo estimado: "<<endl;
        cin>>esfEst;
        Tarea *t1=new Tarea();
        t1->setTarea(n, p, esfEst);
        while(!encontrado){
            cout<<"Nombre del requerimento al que se le asociar� la tarea: "<<endl;
            cin>>nr;
            for(iter=listaRequer.begin();iter!=listaRequer.end();iter++){
                if((*iter)->getNombre()==nr){
                    (*iter)->guardeTarea(t1);
                    encontrado=true;
                }
            }
            if(!encontrado){
                cout<<"Ese nombre no corresponde al de ningun requerimento, ingrese el nombre correctamente"<<endl;
            }
        }
        delete t1;
        break;
    }
}
