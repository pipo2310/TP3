#include "Tarea.h"

Tarea::Tarea()
{
    //ctor
}

Tarea::~Tarea()
{
    //dtor
}

void Tarea::setTarea(string n, int pri, float tiempEstim){
    nombre=n;
    prioridad=pri;
    esfuerzoEstimado=tiempEstim;
}

int Tarea::getPrioridad(){
    return prioridad;
}

string Tarea::getDatos(){
    stringstream datos;
    datos<<"Nombre: "<<nombre<<"\n"<<"Prioridad: "<<prioridad<<"\n"<<"Esfuerzo estimado: "<<esfuerzoEstimado<<endl;
    return datos.str();
}
